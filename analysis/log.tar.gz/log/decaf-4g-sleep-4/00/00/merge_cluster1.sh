#!/bin/bash
set -e

LAUNCH_DIR=`pwd`
echo "Job Launched in directory $LAUNCH_DIR"
source $DECAF_ENV_SOURCE


# copy the json file for the job into the directory
# where we are going to launch decaf
cp linear2.json $PEGASUS_SCRATCH_DIR/

cd $PEGASUS_SCRATCH_DIR
echo "Invoking decaf executable from directory `pwd`"
cat <<EOF > merge_cluster1.conf
0 ./keg_root -D 1 -i f0.txt -o f1.txt -s 2
1 ./keg_inter -D 2 -i f1.txt -o f2.txt -s 2
2 ./keg_inter -D 2 -i f2.txt -o f3.txt -s 2
3 ./keg_inter -D 2 -i f3.txt -o f4.txt -s 2
4 ./keg_leaf -D 0 -i f4.txt -o f5.txt -s 2
EOF
srun --multi-prog ./merge_cluster1.conf

